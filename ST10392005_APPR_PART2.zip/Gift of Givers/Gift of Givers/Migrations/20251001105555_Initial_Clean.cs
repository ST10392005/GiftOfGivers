﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Gift_of_Givers.Migrations
{
    /// <inheritdoc />
    public partial class Initial_Clean : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
