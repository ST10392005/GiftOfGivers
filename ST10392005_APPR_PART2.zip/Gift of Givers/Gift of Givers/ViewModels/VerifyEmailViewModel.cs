﻿using System.ComponentModel.DataAnnotations;

namespace Gift_of_Givers.ViewModels
{
    public class VerifyEmailViewModel
    {
        [Required(ErrorMessage ="Email is Required.")]
        [EmailAddress]
        public string? Email { get; set; }
    }
}
