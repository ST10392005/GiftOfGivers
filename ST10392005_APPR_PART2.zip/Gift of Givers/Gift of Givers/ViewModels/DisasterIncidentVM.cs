﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Gift_of_Givers.ViewModels
{
    public class DisasterIncidentVM
    {
        public int? Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required]
        public string Location { get; set; } = string.Empty;

        [Required]
        public string DisasterType { get; set; } = "Other";

        [DataType(DataType.Date)]
        public DateTime DateOfIncident { get; set; } = DateTime.Today;

        [Required]
        public string Severity { get; set; } = "Low";

        public IFormFile? ImageFile { get; set; }
        public string? ExistingImagePath { get; set; }
    }
}
