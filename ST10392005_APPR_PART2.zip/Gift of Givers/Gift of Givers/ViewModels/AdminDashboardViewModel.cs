﻿using System.Collections.Generic;
using Gift_of_Givers.Models;

namespace Gift_of_Givers.ViewModels
{
    public class AdminDashboardViewModel
    {
        public List<DisasterIncident> Incidents { get; set; } = new();
        public List<Donations> Donations { get; set; } = new();
        public List<Volunteer> Volunteers { get; set; } = new();
    }
}

