﻿using System.ComponentModel.DataAnnotations;

namespace Gift_of_Givers.ViewModels
{
    public class ProfileViewModel
    {
        [Required, MaxLength(100)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Phone]
        [Display(Name = "Cell Number")]
        public string? CellNumber { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
    }
}
