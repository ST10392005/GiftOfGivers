﻿using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Data
{
    public class AppDbContext : IdentityDbContext<User, IdentityRole<int>, int>
    {
        public AppDbContext(DbContextOptions options) : base(options) { }

        public DbSet<DisasterIncident> DisasterIncidents { get; set; } = null!;
        public DbSet<Disaster> Disasters { get; set; } = null!;
        public DbSet<Donations> Donations { get; set; } = null!;
        public DbSet<Volunteer> Volunteers { get; set; } = null!;
        public DbSet<Schedule> Schedules { get; set; } = null!;
        public DbSet<Map> Maps { get; set; } = null!;
        public DbSet<VolunteerTask> VolunteerTasks { get; set; }
        public DbSet<VolunteerAssignment> VolunteerAssignments { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<IdentityRole<int>>().ToTable("Roles");
            modelBuilder.Entity<IdentityUserRole<int>>().ToTable("UserRoles");
            modelBuilder.Entity<IdentityUserClaim<int>>().ToTable("UserClaims");
            modelBuilder.Entity<IdentityUserLogin<int>>().ToTable("UserLogins");
            modelBuilder.Entity<IdentityUserToken<int>>().ToTable("UserTokens");
            modelBuilder.Entity<IdentityRoleClaim<int>>().ToTable("RoleClaims");

            // Map Identity users to "Users" table; PK is Id (int)
            modelBuilder.Entity<User>(b =>
            {
                b.ToTable("Users");
                b.HasKey(u => u.Id);
            });

            // DisasterIncident → User (required, cascade)
            modelBuilder.Entity<DisasterIncident>()
                .HasOne(di => di.User)
                .WithMany()                  // keep WithMany() unless User has ICollection<DisasterIncident>
                .HasForeignKey(di => di.UserId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);

            // Donations → User (required, cascade)
            modelBuilder.Entity<Donations>()
                .HasOne(d => d.User)
                .WithMany(u => u.Donations)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Donations → Disaster (optional, set null)
            modelBuilder.Entity<Donations>()
                .HasOne(d => d.Disaster)
                .WithMany(z => z.Donations)
                .HasForeignKey(d => d.DisasterId)
                .OnDelete(DeleteBehavior.SetNull);

            // Volunteer → User (one-to-one, required, cascade)
            modelBuilder.Entity<Volunteer>()
                .HasOne(v => v.User)
                .WithOne(u => u.Volunteer)
                .HasForeignKey<Volunteer>(v => v.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Schedule → Volunteer (required, cascade)
            modelBuilder.Entity<Schedule>()
                .HasOne(s => s.Volunteer)
                .WithMany(v => v.Schedule)
                .HasForeignKey(s => s.VolunteerId)
                .OnDelete(DeleteBehavior.Cascade);

            // Schedule → Disaster (required, cascade)
            modelBuilder.Entity<Schedule>()
                .HasOne(s => s.Disaster)
                .WithMany(d => d.Schedules)
                .HasForeignKey(s => s.DisasterId)
                .OnDelete(DeleteBehavior.Cascade);

            // Map → Disaster (required, cascade)
            modelBuilder.Entity<Map>()
                .HasOne(m => m.Disaster)
                .WithMany(d => d.Maps)
                .HasForeignKey(m => m.DisasterId)
                .OnDelete(DeleteBehavior.Cascade);

            // VolunteerTask 1-* VolunteerAssignment
            modelBuilder.Entity<VolunteerTask>()
                .HasMany(t => t.Assignments)
                .WithOne(a => a.Task)
                .HasForeignKey(a => a.VolunteerTaskId)
                .OnDelete(DeleteBehavior.Cascade);

            // VolunteerAssignment -> User (many to one)
            modelBuilder.Entity<VolunteerAssignment>()
                .HasOne(a => a.User)
                .WithMany() // you can add ICollection<VolunteerAssignment> in User later if you want
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}

