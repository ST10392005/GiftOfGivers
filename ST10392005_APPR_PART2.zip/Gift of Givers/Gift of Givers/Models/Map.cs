﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_of_Givers.Models
{
    public class Map
    {
        [Key]
        public int MapId { get; set; }

        [Required]
        [ForeignKey("Disaster")]
        public int DisasterId { get; set; }

        [MaxLength(255)]
        public string? HospitalName { get; set; }

        [MaxLength(20)]
        public string? HospitalPhone { get; set; }

        // Navigation property
        public virtual Disaster Disaster { get; set; } = null!;
    }

}
