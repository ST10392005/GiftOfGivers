﻿using System.ComponentModel.DataAnnotations;

namespace Gift_of_Givers.Models
{
    public class Donations
    {
        [Key] public int DonationId { get; set; }

        // FK to Identity user (int PK)
        [Required] public int UserId { get; set; }
        public virtual User? User { get; set; }

        // FK to Disaster (nullable → you use DeleteBehavior.SetNull)
        public int? DisasterId { get; set; }
        public virtual Disaster? Disaster { get; set; }

        // Form fields
        [Required] public string ResourceType { get; set; } = string.Empty; // Food/Clothing/Medical/Other
        [Range(1, 1_000_000)] public int Quantity { get; set; } = 1;
        [Required] public string Location { get; set; } = string.Empty;

        // Donor info
        [Required, MaxLength(100)] public string DonorName { get; set; } = string.Empty;
        [Required, EmailAddress] public string DonorEmail { get; set; } = string.Empty;
        [Phone] public string? DonorPhone { get; set; }

        // Status/timestamp
        [Required] public string Status { get; set; } = "Pending";
        public DateTime DonationDate { get; set; } = DateTime.UtcNow;
    }
}

