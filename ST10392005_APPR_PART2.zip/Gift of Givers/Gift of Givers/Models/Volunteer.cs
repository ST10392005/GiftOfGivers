﻿using System.ComponentModel.DataAnnotations;

namespace Gift_of_Givers.Models
{
    public class Volunteer
    {
        [Key] public int VolunteerId { get; set; }
        [Required] public int UserId { get; set; }

        [Required, MaxLength(100)] public string FullName { get; set; } = string.Empty;
        [Required, EmailAddress] public string Email { get; set; } = string.Empty;
        [Phone] public string? Phone { get; set; }
        [MaxLength(300)] public string? Skills { get; set; }

        // Required by your DbContext mappings
        public virtual User? User { get; set; }
        public virtual ICollection<Schedule> Schedule { get; set; } = new List<Schedule>();
    }


    public class VolunteerTask
    {
        public int VolunteerTaskId { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(300)]
        public string? Description { get; set; }

        [Required, MaxLength(120)]
        public string Location { get; set; } = string.Empty;

        public DateTime StartTime { get; set; } = DateTime.UtcNow.AddDays(1);

        [Range(1, 500)]
        public int Slots { get; set; } = 5;

        // Navigation
        public virtual ICollection<VolunteerAssignment> Assignments { get; set; } = new List<VolunteerAssignment>();
    }

    // A volunteer joining a task
    public class VolunteerAssignment
    {
        public int VolunteerAssignmentId { get; set; }
        public int VolunteerTaskId { get; set; }   // FK -> VolunteerTask
        public int UserId { get; set; }            // FK -> Users (Identity)

        [Required, MaxLength(30)]
        public string Status { get; set; } = "Not Started"; // Not Started / In Progress / Completed

        public DateTime AssignedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public virtual VolunteerTask Task { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}




