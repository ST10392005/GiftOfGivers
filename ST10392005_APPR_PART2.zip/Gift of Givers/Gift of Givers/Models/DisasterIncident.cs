﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_of_Givers.Models
{
    public class DisasterIncident
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required, StringLength(120)]
        public string Location { get; set; } = string.Empty;

        // Extra fields for the assignment
        [Required, StringLength(40)]
        public string DisasterType { get; set; } = "Other";

        [DataType(DataType.Date)]
        public DateTime DateOfIncident { get; set; } = DateTime.Today;

        [Required, StringLength(20)]
        public string Severity { get; set; } = "Low"; // Low/Moderate/Severe/Critical

        [StringLength(256)]
        public string? ImagePath { get; set; }

        public DateTime DateReported { get; set; } = DateTime.UtcNow;

        [Required, StringLength(30)]
        public string Status { get; set; } = "Pending";

        // Link to logged-in user
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public User User { get; set; } = null!;
    }
}
