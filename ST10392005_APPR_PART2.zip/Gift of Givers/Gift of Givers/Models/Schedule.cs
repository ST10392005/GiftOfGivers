﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_of_Givers.Models
{
    public class Schedule
    {
        [Key]
        public int ScheduleId { get; set; }

        [Required]
        [ForeignKey("Volunteer")]
        public int VolunteerId { get; set; }

        [Required]
        [ForeignKey("Disaster")]
        public int DisasterId { get; set; }

        [Required]
        public DateOnly ScheduledDate { get; set; }

        // Navigation properties
        public virtual Volunteer Volunteer { get; set; } = null!;
        public virtual Disaster Disaster { get; set; } = null!;
    }
}

