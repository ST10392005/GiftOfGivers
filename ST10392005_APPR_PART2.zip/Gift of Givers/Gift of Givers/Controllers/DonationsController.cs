﻿// Controllers/DonationsController.cs
using System.Linq;
using System.Threading.Tasks;
using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Authorize]
    public class DonationsController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public DonationsController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var me = await _userManager.GetUserAsync(User);
            var isAdmin = User.IsInRole("Admin");

            var q = _db.Donations.AsQueryable();
            if (!isAdmin) q = q.Where(d => d.UserId == me!.Id);

            var list = await q.OrderByDescending(d => d.DonationDate).ToListAsync();
            return View(list);
        }

        [HttpGet]
        public IActionResult Create() => View(new Donations());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Donations donation)
        {
            if (!ModelState.IsValid) return View(donation);

            var me = await _userManager.GetUserAsync(User);
            donation.UserId = me!.Id;
            if (donation.DonationDate == default) donation.DonationDate = System.DateTime.UtcNow;

            _db.Donations.Add(donation);
            await _db.SaveChangesAsync();

            TempData["Ok"] = "Thank you for your donation.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(int id)
        {
            var item = await _db.Donations.FirstOrDefaultAsync(x => x.DonationId == id);
            if (item == null) return NotFound();

            var me = await _userManager.GetUserAsync(User);
            if (!User.IsInRole("Admin") && item.UserId != me!.Id) return Forbid();

            return View(item);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _db.Donations.FindAsync(id);
            if (item == null) return NotFound();

            var me = await _userManager.GetUserAsync(User);
            if (!User.IsInRole("Admin") && item.UserId != me!.Id) return Forbid();

            return View(item);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _db.Donations.FindAsync(id);
            if (item == null) return NotFound();

            var me = await _userManager.GetUserAsync(User);
            if (!User.IsInRole("Admin") && item.UserId != me!.Id) return Forbid();

            _db.Donations.Remove(item);
            await _db.SaveChangesAsync();

            TempData["Ok"] = "Donation removed.";
            return RedirectToAction(nameof(Index));
        }
    }
}

