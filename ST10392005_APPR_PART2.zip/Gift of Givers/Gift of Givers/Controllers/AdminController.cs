﻿using System.Threading.Tasks;
using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public AdminController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        // Simple dashboard with counts pulled from EF
        public async Task<IActionResult> Index()
        {
            ViewBag.Users = await _userManager.Users.CountAsync();
            ViewBag.Incidents = await _db.DisasterIncidents.CountAsync();
            ViewBag.Donations = await _db.Donations.CountAsync();
            ViewBag.Tasks = await _db.VolunteerTasks.CountAsync();
            ViewBag.Assignments = await _db.VolunteerAssignments.CountAsync();
            return View();
        }
    }
}
