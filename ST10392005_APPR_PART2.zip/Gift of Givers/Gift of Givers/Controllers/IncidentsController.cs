﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Authorize]
    public class IncidentsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<User> _userManager;
        private readonly IWebHostEnvironment _env;

        public IncidentsController(
            AppDbContext context,
            UserManager<User> userManager,
            IWebHostEnvironment env)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
        }

        private bool IsAdmin => User.IsInRole("Admin");

        // GET: /Incidents  (supports ?location=&severity=&status=)
        [HttpGet]
        public async Task<IActionResult> Index(string? location, string? severity, string? status)
        {
            var me = await _userManager.GetUserAsync(User);
            var userId = me!.Id;

            IQueryable<DisasterIncident> query = _context.DisasterIncidents;

            if (!IsAdmin) query = query.Where(i => i.UserId == userId);
            if (!string.IsNullOrWhiteSpace(location)) query = query.Where(i => i.Location.Contains(location));
            if (!string.IsNullOrWhiteSpace(severity) && severity != "All") query = query.Where(i => i.Severity == severity);
            if (!string.IsNullOrWhiteSpace(status) && status != "All") query = query.Where(i => i.Status == status);

            var list = await query.OrderByDescending(i => i.DateReported).ToListAsync();

            ViewData["LocationFilter"] = location ?? "";
            ViewData["SeverityFilter"] = severity ?? "All";
            ViewData["StatusFilter"] = status ?? "All";
            return View(list);
        }

        // ---------- CREATE ----------

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var me = await _userManager.GetUserAsync(User);

            ViewBag.Recent = await _context.DisasterIncidents
                .Where(i => i.UserId == me!.Id)
                .OrderByDescending(i => i.DateReported)
                .Take(6)
                .ToListAsync();

            // Pre-fill date for convenience
            return View(new DisasterIncident { DateOfIncident = DateTime.Today });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DisasterIncident incident, IFormFile? image)
        {
            // ✅ Set server-side fields BEFORE validation
            var me = await _userManager.GetUserAsync(User);
            incident.UserId = me!.Id;
            incident.Status = string.IsNullOrWhiteSpace(incident.Status) ? "Pending" : incident.Status;
            if (incident.DateReported == default) incident.DateReported = DateTime.UtcNow;

            // ✅ Remove model-state keys we populate server-side (prevents false invalid)
            ModelState.Remove(nameof(DisasterIncident.UserId));
            ModelState.Remove(nameof(DisasterIncident.User));

            if (!ModelState.IsValid)
            {
                // rehydrate recent for the view
                ViewBag.Recent = await _context.DisasterIncidents
                    .Where(i => i.UserId == me.Id)
                    .OrderByDescending(i => i.DateReported)
                    .Take(6)
                    .ToListAsync();

                return View(incident);
            }

            // Optional image upload
            if (image is not null && image.Length > 0)
            {
                var ext = Path.GetExtension(image.FileName).ToLowerInvariant();
                var ok = new[] { ".jpg", ".jpeg", ".png" };
                if (!ok.Contains(ext) || image.Length > 4 * 1024 * 1024)
                {
                    ModelState.AddModelError("", "Only .jpg/.jpeg/.png up to 4MB are allowed.");
                    ViewBag.Recent = await _context.DisasterIncidents
                        .Where(i => i.UserId == me.Id)
                        .OrderByDescending(i => i.DateReported)
                        .Take(6)
                        .ToListAsync();
                    return View(incident);
                }

                var uploadsDir = Path.Combine(_env.WebRootPath, "uploads", "incidents");
                Directory.CreateDirectory(uploadsDir);
                var fileName = $"{Guid.NewGuid()}{ext}";
                var fullPath = Path.Combine(uploadsDir, fileName);
                using (var fs = System.IO.File.Create(fullPath))
                    await image.CopyToAsync(fs);

                incident.ImagePath = $"/uploads/incidents/{fileName}";
            }

            _context.Add(incident);
            await _context.SaveChangesAsync();

            TempData["Ok"] = "Incident submitted. Thank you!";
            return RedirectToAction(nameof(Index));
        }

        // ---------- DETAILS ----------

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.DisasterIncidents
                .Include(i => i.User)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (item == null) return NotFound();
            if (!IsAdmin && item.UserId != (await _userManager.GetUserAsync(User))!.Id) return Forbid();

            return View(item);
        }

        // ---------- EDIT ----------

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.DisasterIncidents.FindAsync(id);
            if (item == null) return NotFound();
            if (!IsAdmin && item.UserId != (await _userManager.GetUserAsync(User))!.Id) return Forbid();

            return View(item);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DisasterIncident model, IFormFile? image)
        {
            if (id != model.Id) return NotFound();

            // server-controlled fields should not block validation
            ModelState.Remove(nameof(DisasterIncident.UserId));
            ModelState.Remove(nameof(DisasterIncident.User));

            if (!ModelState.IsValid) return View(model);

            var item = await _context.DisasterIncidents.FirstOrDefaultAsync(i => i.Id == id);
            if (item == null) return NotFound();
            if (!IsAdmin && item.UserId != (await _userManager.GetUserAsync(User))!.Id) return Forbid();

            item.Title = model.Title;
            item.Description = model.Description;
            item.Location = model.Location;
            item.DisasterType = model.DisasterType;
            item.DateOfIncident = model.DateOfIncident;
            item.Severity = model.Severity;
            item.Status = model.Status;

            if (image is not null && image.Length > 0)
            {
                var ext = Path.GetExtension(image.FileName).ToLowerInvariant();
                var ok = new[] { ".jpg", ".jpeg", ".png" };
                if (!ok.Contains(ext) || image.Length > 4 * 1024 * 1024)
                {
                    ModelState.AddModelError("", "Only .jpg/.jpeg/.png up to 4MB are allowed.");
                    return View(model);
                }

                var uploadsDir = Path.Combine(_env.WebRootPath, "uploads", "incidents");
                Directory.CreateDirectory(uploadsDir);
                var fileName = $"{Guid.NewGuid()}{ext}";
                var fullPath = Path.Combine(uploadsDir, fileName);
                using (var fs = System.IO.File.Create(fullPath))
                    await image.CopyToAsync(fs);

                item.ImagePath = $"/uploads/incidents/{fileName}";
            }

            await _context.SaveChangesAsync();
            TempData["Ok"] = "Incident updated.";
            return RedirectToAction(nameof(Index));
        }

        // ---------- DELETE ----------

        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var item = await _context.DisasterIncidents
                .FirstOrDefaultAsync(i => i.Id == id);
            if (item == null) return NotFound();
            if (!IsAdmin && item.UserId != (await _userManager.GetUserAsync(User))!.Id) return Forbid();

            return View(item);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _context.DisasterIncidents.FindAsync(id);
            if (item == null) return NotFound();
            if (!IsAdmin && item.UserId != (await _userManager.GetUserAsync(User))!.Id) return Forbid();

            _context.DisasterIncidents.Remove(item);
            await _context.SaveChangesAsync();

            TempData["Ok"] = "Incident deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
