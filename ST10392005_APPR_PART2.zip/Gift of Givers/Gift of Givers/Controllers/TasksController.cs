﻿using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Authorize]
    public class TasksController : Controller
    {
        private readonly AppDbContext _ctx;
        private readonly UserManager<User> _userManager;

        public TasksController(AppDbContext ctx, UserManager<User> userManager)
        {
            _ctx = ctx;
            _userManager = userManager;
        }

        // List available tasks (and show whether I'm joined)
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var me = await _userManager.GetUserAsync(User);
            var tasks = await _ctx.VolunteerTasks
                                  .Include(t => t.Assignments)
                                  .OrderBy(t => t.StartTime)
                                  .ToListAsync();

            var myTaskIds = await _ctx.VolunteerAssignments
                                      .Where(a => a.UserId == me!.Id)
                                      .Select(a => a.VolunteerTaskId)
                                      .ToListAsync();

            ViewBag.MyTaskIds = new HashSet<int>(myTaskIds);
            return View(tasks);
        }

        // Admin: create a new task
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult Create() => View();

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(VolunteerTask vm)
        {
            if (!ModelState.IsValid) return View(vm);

            _ctx.VolunteerTasks.Add(vm);
            await _ctx.SaveChangesAsync();
            TempData["Ok"] = "Task created.";
            return RedirectToAction(nameof(Index));
        }

        // Join a task (if slots available)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Join(int id)
        {
            var me = await _userManager.GetUserAsync(User);
            var task = await _ctx.VolunteerTasks
                                 .Include(t => t.Assignments)
                                 .FirstOrDefaultAsync(t => t.VolunteerTaskId == id);
            if (task == null) return NotFound();

            // already joined?
            var already = await _ctx.VolunteerAssignments
                                    .AnyAsync(a => a.VolunteerTaskId == id && a.UserId == me!.Id);
            if (already)
            {
                TempData["Err"] = "You already joined this task.";
                return RedirectToAction(nameof(Index));
            }

            // capacity check
            var taken = task.Assignments.Count;
            if (taken >= task.Slots)
            {
                TempData["Err"] = "This task is full.";
                return RedirectToAction(nameof(Index));
            }

            _ctx.VolunteerAssignments.Add(new VolunteerAssignment
            {
                VolunteerTaskId = id,
                UserId = me!.Id,
                Status = "Not Started",
                AssignedAt = DateTime.UtcNow
            });

            await _ctx.SaveChangesAsync();
            TempData["Ok"] = "You're in! Thank you for volunteering.";
            return RedirectToAction(nameof(MyAssignments));
        }

        // My assignments
        [HttpGet]
        public async Task<IActionResult> MyAssignments()
        {
            var me = await _userManager.GetUserAsync(User);
            var mine = await _ctx.VolunteerAssignments
                                 .Include(a => a.Task)
                                 .Where(a => a.UserId == me!.Id)
                                 .OrderBy(a => a.Task.StartTime)
                                 .ToListAsync();
            return View(mine);
        }

        // Update my assignment status
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var me = await _userManager.GetUserAsync(User);
            var a = await _ctx.VolunteerAssignments
                              .Include(x => x.Task)
                              .FirstOrDefaultAsync(x => x.VolunteerAssignmentId == id);
            if (a == null) return NotFound();

            // Only the assignee or Admin can update
            if (a.UserId != me!.Id && !User.IsInRole("Admin")) return Forbid();

            var allowed = new[] { "Not Started", "In Progress", "Completed" };
            if (!allowed.Contains(status))
            {
                TempData["Err"] = "Invalid status.";
                return RedirectToAction(nameof(MyAssignments));
            }

            a.Status = status;
            await _ctx.SaveChangesAsync();
            TempData["Ok"] = "Status updated.";
            return RedirectToAction(nameof(MyAssignments));
        }
    }
}
