﻿using System.Linq;
using System.Threading.Tasks;
using Gift_of_Givers.Models;
using Gift_of_Givers.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Gift_of_Givers.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<User> _signInManager;
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<IdentityRole<int>> _roleManager;

        public AccountController(
            SignInManager<User> signInManager,
            UserManager<User> userManager,
            RoleManager<IdentityRole<int>> roleManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // ---------- LOGIN ----------
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login() => View();

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var email = (model.Email ?? string.Empty).Trim();
            if (string.IsNullOrEmpty(email))
            {
                ModelState.AddModelError("", "Email is required.");
                return View(model);
            }

            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            var result = await _signInManager.CheckPasswordSignInAsync(
                user, model.Password, lockoutOnFailure: true);

            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(user, isPersistent: model.RememberMe);
                return RedirectToAction("Index", "Home");
            }

            if (result.IsLockedOut)
                ModelState.AddModelError("", "Account locked. Please try again later.");
            else if (result.IsNotAllowed)
                ModelState.AddModelError("", "Sign-in not allowed.");
            else
                ModelState.AddModelError("", "Invalid email or password.");

            return View(model);
        }

        // ---------- REGISTER ----------
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register() => View();

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var parts = (model.FullName ?? string.Empty)
                .Split(' ', 2, System.StringSplitOptions.RemoveEmptyEntries);

            var user = new User
            {
                FirstName = parts.ElementAtOrDefault(0) ?? "",
                LastName = parts.ElementAtOrDefault(1) ?? "",
                CellNumber = model.CellNumber,
                UserName = model.Email,
                Email = model.Email,
                EmailConfirmed = true // dev mode: skip email confirmation
            };

            var result = await _userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
            {
                foreach (var e in result.Errors) ModelState.AddModelError("", e.Description);
                return View(model);
            }

            await EnsureRolesExist();
            await _userManager.AddToRoleAsync(user, "User");
            await _signInManager.SignInAsync(user, isPersistent: false);

            return RedirectToAction("Index", "Home");
        }

        // ---------- PROFILE (view/edit) ----------
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            var me = await _userManager.GetUserAsync(User);
            if (me == null) return RedirectToAction(nameof(Login));

            var vm = new ProfileViewModel
            {
                FirstName = me.FirstName,
                LastName = me.LastName,
                CellNumber = me.CellNumber,
                Email = me.Email ?? ""
            };
            return View(vm);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(ProfileViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var me = await _userManager.GetUserAsync(User);
            if (me == null) return RedirectToAction(nameof(Login));

            me.FirstName = vm.FirstName?.Trim() ?? "";
            me.LastName = vm.LastName?.Trim() ?? "";
            me.CellNumber = string.IsNullOrWhiteSpace(vm.CellNumber) ? null : vm.CellNumber.Trim();

            // allow email change (and keep username == email)
            var newEmail = (vm.Email ?? "").Trim();
            if (!string.IsNullOrEmpty(newEmail) &&
                !string.Equals(newEmail, me.Email, System.StringComparison.OrdinalIgnoreCase))
            {
                me.Email = newEmail;
                me.UserName = newEmail;
                me.NormalizedEmail = newEmail.ToUpperInvariant();
                me.NormalizedUserName = newEmail.ToUpperInvariant();
            }

            var result = await _userManager.UpdateAsync(me);
            if (!result.Succeeded)
            {
                foreach (var e in result.Errors) ModelState.AddModelError("", e.Description);
                return View(vm);
            }

            TempData["ProfileSaved"] = "Profile updated.";
            return RedirectToAction(nameof(Profile));
        }

        // ---------- CHANGE PASSWORD (no old password; uses reset token) ----------
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> ChangePassword()
        {
            var me = await _userManager.GetUserAsync(User);
            if (me == null) return RedirectToAction(nameof(Login));

            // reuse your existing view model shape (Email shown as read-only)
            var vm = new ChangePasswordViewModel { Email = me.Email };
            return View(vm);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var me = await _userManager.GetUserAsync(User);
            if (me == null) return RedirectToAction(nameof(Login));

            // Generate a reset token and set the new password (dev-friendly flow)
            var token = await _userManager.GeneratePasswordResetTokenAsync(me);
            var result = await _userManager.ResetPasswordAsync(me, token, vm.NewPassword!);

            if (!result.Succeeded)
            {
                foreach (var e in result.Errors) ModelState.AddModelError("", e.Description);
                return View(vm);
            }

            TempData["ProfileSaved"] = "Password updated.";
            return RedirectToAction(nameof(Profile));
        }

        // ---------- LOGOUT ----------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction(nameof(Login));
        }

        // ---------- Helpers ----------
        private async Task EnsureRolesExist()
        {
            var roles = new[] { "Admin", "User" };
            foreach (var role in roles)
            {
                if (!await _roleManager.RoleExistsAsync(role))
                {
                    await _roleManager.CreateAsync(new IdentityRole<int> { Name = role });
                }
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult AccessDenied() => View();
    }
}

