﻿using System.Linq;
using System.Threading.Tasks;
using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Authorize]
    public class VolunteerController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public VolunteerController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        // Browse available tasks (with taken/slots info)
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var tasks = await _db.VolunteerTasks
                .OrderBy(t => t.StartTime)
                .ToListAsync();

            // Preload assignment counts
            var counts = await _db.VolunteerAssignments
                .GroupBy(a => a.VolunteerTaskId)
                .Select(g => new { TaskId = g.Key, Cnt = g.Count() })
                .ToDictionaryAsync(x => x.TaskId, x => x.Cnt);

            ViewBag.Counts = counts; // used by the view to show "X / Slots"
            return View(tasks);
        }

        // Join a task
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Join(int id)
        {
            var me = await _userManager.GetUserAsync(User);

            var task = await _db.VolunteerTasks.FindAsync(id);
            if (task == null) return NotFound();

            // Already joined?
            var exists = await _db.VolunteerAssignments
                .AnyAsync(a => a.VolunteerTaskId == id && a.UserId == me!.Id);
            if (exists)
            {
                TempData["Ok"] = "You are already assigned to this task.";
                return RedirectToAction(nameof(Index));
            }

            // Capacity check
            var taken = await _db.VolunteerAssignments.CountAsync(a => a.VolunteerTaskId == id);
            if (taken >= task.Slots)
            {
                TempData["Ok"] = "This task is full.";
                return RedirectToAction(nameof(Index));
            }

            _db.VolunteerAssignments.Add(new VolunteerAssignment
            {
                VolunteerTaskId = id,
                UserId = me!.Id,
                Status = "Not Started"
            });
            await _db.SaveChangesAsync();

            TempData["Ok"] = "Joined task. Thank you!";
            return RedirectToAction(nameof(MyAssignments));
        }

        // See my assignments
        [HttpGet]
        public async Task<IActionResult> MyAssignments()
        {
            var me = await _userManager.GetUserAsync(User);
            var mine = await _db.VolunteerAssignments
                .Include(a => a.Task)
                .Where(a => a.UserId == me!.Id)
                .OrderBy(a => a.Task.StartTime)
                .ToListAsync();

            return View(mine);
        }

        // Update my assignment status
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SetStatus(int id, string status)
        {
            var me = await _userManager.GetUserAsync(User);
            var a = await _db.VolunteerAssignments.Include(x => x.Task)
                .FirstOrDefaultAsync(x => x.VolunteerAssignmentId == id);
            if (a == null) return NotFound();

            if (!User.IsInRole("Admin") && a.UserId != me!.Id) return Forbid();

            var allowed = new[] { "Not Started", "In Progress", "Completed" };
            if (!allowed.Contains(status)) status = "Not Started";

            a.Status = status;
            await _db.SaveChangesAsync();

            TempData["Ok"] = "Status updated.";
            return RedirectToAction(nameof(MyAssignments));
        }

        // Leave an assignment (optional)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Leave(int id)
        {
            var me = await _userManager.GetUserAsync(User);
            var a = await _db.VolunteerAssignments
                .FirstOrDefaultAsync(x => x.VolunteerAssignmentId == id);
            if (a == null) return NotFound();

            if (!User.IsInRole("Admin") && a.UserId != me!.Id) return Forbid();

            _db.VolunteerAssignments.Remove(a);
            await _db.SaveChangesAsync();

            TempData["Ok"] = "You left the task.";
            return RedirectToAction(nameof(MyAssignments));
        }
    }
}
