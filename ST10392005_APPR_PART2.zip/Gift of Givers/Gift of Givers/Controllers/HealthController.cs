﻿using Gift_of_Givers.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_Givers.Controllers
{
    [Route("health")]
    public class HealthController : Controller
    {
        private readonly AppDbContext _db;
        public HealthController(AppDbContext db) => _db = db;

        [HttpGet("db")]
        public async Task<IActionResult> Db()
        {
            var canConnect = await _db.Database.CanConnectAsync();
            var migs = await _db.Database.GetAppliedMigrationsAsync();
            var users = await _db.Users.CountAsync();

            return Ok(new
            {
                canConnect,
                appliedMigrations = migs.Count(),
                users
            });
        }
    }
}


