﻿using System;
using System.Linq;
using System;
using System.Linq;
using System.Threading.Tasks;
using Gift_of_Givers.Data;
using Gift_of_Givers.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;  // << required for CreateScope()
using Microsoft.Extensions.Logging;

namespace Gift_of_Givers.Services
{
    public static class SeedService
    {
        /// Seeds roles ("Admin", "User"), a starter admin user, and demo Volunteer Tasks.
        /// Assumes migrations are applied before this runs.
        public static async Task SeedDatabase(IServiceProvider services)
        {
            using var scope = services.CreateScope();
            var sp = scope.ServiceProvider;
            var context = sp.GetRequiredService<AppDbContext>();
            var roleManager = sp.GetRequiredService<RoleManager<IdentityRole<int>>>();
            var userManager = sp.GetRequiredService<UserManager<User>>();
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger("SeedService");

            try
            {
                // 1) Roles
                await EnsureRole(roleManager, "Admin");
                await EnsureRole(roleManager, "User");

                // 2) Admin user
                // SeedService.cs  (inside SeedDatabase)
                const string adminEmail = "seed-admin@gog.local";   // <-- not a real domain; never collides
                const string adminPwd = "Admin(123)";


                var admin = await userManager.FindByEmailAsync(adminEmail);
                if (admin is null)
                {
                    admin = new User
                    {
                        FirstName = "Code",
                        LastName = "Hub",
                        UserName = adminEmail,
                        NormalizedUserName = adminEmail.ToUpperInvariant(),
                        Email = adminEmail,
                        NormalizedEmail = adminEmail.ToUpperInvariant(),
                        EmailConfirmed = true,
                        SecurityStamp = Guid.NewGuid().ToString()
                    };

                    var create = await userManager.CreateAsync(admin, adminPwd);
                    if (!create.Succeeded)
                    {
                        logger.LogError("Create admin failed: {Errors}",
                            string.Join(", ", create.Errors.Select(e => e.Description)));
                        return;
                    }
                }

                if (!await userManager.IsInRoleAsync(admin, "Admin"))
                {
                    var add = await userManager.AddToRoleAsync(admin, "Admin");
                    if (!add.Succeeded)
                        logger.LogWarning("AddToRole(Admin) failed: {Errors}",
                            string.Join(", ", add.Errors.Select(e => e.Description)));
                }

                // 3) Demo Volunteer Tasks (only if none exist)
                // NOTE: requires DbSet<VolunteerTask> VolunteerTasks in AppDbContext.
                if (!await context.VolunteerTasks.AnyAsync())
                {
                    context.VolunteerTasks.AddRange(
                        new VolunteerTask
                        {
                            Name = "Cleanup Team",
                            Description = "Street & debris cleanup",
                            Location = "Cape Town CBD",
                            StartTime = DateTime.UtcNow.AddDays(2),
                            Slots = 8
                        },
                        new VolunteerTask
                        {
                            Name = "Aid Distribution",
                            Description = "Distribute food parcels",
                            Location = "Khayelitsha",
                            StartTime = DateTime.UtcNow.AddDays(3),
                            Slots = 5
                        }
                    );
                    await context.SaveChangesAsync();
                    logger.LogInformation("Seeded demo Volunteer Tasks.");
                }

                logger.LogInformation("Seeding complete.");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Seeding error.");
            }
        }

        private static async Task EnsureRole(RoleManager<IdentityRole<int>> roles, string name)
        {
            if (!await roles.RoleExistsAsync(name))
            {
                var result = await roles.CreateAsync(new IdentityRole<int> { Name = name });
                if (!result.Succeeded)
                    throw new Exception($"Create role '{name}' failed: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }
    }
}
